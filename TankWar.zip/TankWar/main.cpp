#include "mainwindow.h"

#include <QApplication>
#include <QSplashScreen>
#include <QPoint>


INFO info;

int main(int argc, char *argv[])
{
    QPoint *p1;
    QPoint *p2;
    p1 = new QPoint(700,200);
    p2 = new QPoint(600,50);
    QApplication a(argc, argv);

    //设置全局字体
    QFont font("Microsoft YaHei UI",14);
    a.setFont(font);

    QPixmap pixmap(":/new/prefix1/start.png");
    QSplashScreen splash(pixmap);
    splash.move(*p1);
    splash.show();
    a.processEvents();

    MainWindow w;
    w.move(*p2);
    w.show();
    splash.finish(&w);

    return a.exec();
}
